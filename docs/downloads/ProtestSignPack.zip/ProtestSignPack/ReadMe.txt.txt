Free printable protest signs.

Download, print, and share.


PRINTING NOTES
Letter-size signs are ready to print on 8.5 x 11 paper. 
Print setting: fit to printable area.

Poster files are designed to print across four pages.
Print setting: fit to printable area.
Trim edges and tape or glue together.

PROTEST SAFETY TIPS
(coming Soon)

BASIC WHEAT PASTE INSTRUCTIONS
Mix 1 cup flour with 1 cup water until smooth.
Boil 3 cups water.
Slowly stir in the flour mixture.
Simmer until thick.
Let cool before use.

Brush onto surface, apply poster, brush a thin layer on top.

CREDITS
Artwork by community contributors.
Free to print and distribute.




